## Project: Pick & Drop 

### Project completion steps ###

1. First make sure you have created workspace for ROS.
2. Make clone the project repossitory which can download from the path 
   "https://github.com/udacity/RoboND-Kinematics-Project" inside catkin_ws/src  directory.
3. Work with forward kinematics to get experince in robotic envirenment with gazebo simulator.
4. Launch the video to understand the kinemetics at path "https://www.youtube.com/watch?v=Gt8DRm-REt4"
5. Launch in [demo mode](https://classroom.udacity.com/nanodegrees/nd209/parts/7b2fd2d7-e181-401e-977a-6158c77bf816/
                         modules/8855de3f-2897-46c3-a805-628b5ecf045b/lessons/91d017b1-4493-4522-ad52-04a74a01094c/
						 concepts/ae64bb91-e8c4-44c9-adbe-798e8f688193).
6. Do Kinematic Analysis for the robot, following the [project rubric](https://review.udacity.com/#!/rubrics/972/view).
7. Needs to be calculate the Inverse Kinemetics code to fill the IK_server.py file.

[//]: # (Image References)

[image1]: ./misc_images/misc1.png
[image2]: ./misc_images/misc1.png
[image3]: ./misc_images/misc1.png 		

###  README	/ Writeup

1. Provide a Writeup / README that includes all the rubric points and how you addressed each one.
   You can submit your writeup as markdown or pdf.  
   
You're reading it!   

### Kinematic Analysis

1. First Run the forward_kinematics demo and evaluate the kr210.urdf.xacro file to perform kinematic 
   analysis of Kuka KR210 robot and derive its DH parameters.

Here is an example of how to include an image in your writeup.
![alt text][image1]

2. Using the DH parameter table you derived earlier, create individual transformation matrices about each joint. In addition, 
   also generate a generalized homogeneous transform between base_link and gripper_link using only end-effector(gripper) pose.

Links | alpha(i-1) | a(i-1) | d(i-1) | theta(i)
---   | --- | --- | --- | ---
0->1  | 0 | 0 | L1 | qi
1->2  | - pi/2 | L2 | 0 | -pi/2 + q2
2->3  | 0 | 0 | 0 | 0
3->4  | 0 | 0 | 0 | 0
4->5  | 0 | 0 | 0 | 0
5->6  | 0 | 0 | 0 | 0
6->EE | 0 | 0 | 0 | 0
  
3. Decouple Inverse Kinematics problem into Inverse Position Kinematics and inverse Orientation Kinematics; 
  doing so derive the equations to calculate all individual joint angles.

And here's where you can draw out and show your math for the derivation of your theta angles. 

![alt text][image2]
  
### Project Implementation

1. Fill in the 'IK_server.py' file with properly commented python code for calculating Inverse Kinematics based on previously 
   performed Kinematic Analysis. Your code must guide the robot to successfully complete 8/10 pick and place cycles. 
   Briefly discuss the code you implemented and your results. 
   
Here I'll talk about the code, what techniques I used, what worked and why, where the implementation might fail and how 
I might improve it if I were going to pursue this project further.     