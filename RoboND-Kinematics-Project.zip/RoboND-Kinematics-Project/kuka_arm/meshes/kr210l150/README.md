Mesh files present in this folder were obtained from:
https://github.com/ros-industrial/kuka_experimental
